#' Filter rows of a GPU table
#'
#' Selects rows from a GPU table where conditions are TRUE, similar to
#' `dplyr::filter()`. Filtering is performed entirely on the GPU for
#' maximum performance on large datasets.
#'
#' @param .data A `tbl_gpu` object created by [tbl_gpu()].
#' @param ... Logical expressions to filter by. Each expression should be
#'   a comparison of the form `column <op> value` or `column <op> column`.
#'   Multiple conditions are combined with AND (all must be TRUE).
#' @param .preserve Ignored. Included for compatibility with dplyr generic.
#'
#' @return A `tbl_gpu` object containing only rows where all conditions are TRUE.
#'   The GPU memory for the filtered result is newly allocated.
#'
#' @details
#' ## Supported comparison operators
#' \itemize{
#'   \item `==` - equal to
#'   \item `!=` - not equal to
#'   \item `>` - greater than
#'   \item `>=` - greater than or equal to
#'   \item `<` - less than
#'   \item `<=` - less than or equal to
#' }
#'
#' ## Current limitations
#' \itemize{
#'   \item Only simple comparisons are supported (column op value/column)
#'   \item Compound expressions with `&` or `|` are not yet supported
#'   \item String comparisons are not yet implemented
#'   \item Only numeric scalar values on the right-hand side
#' }
#'
#' ## Performance
#' Filtering on GPU is highly parallel and can process billions of rows
#' per second. For best performance, chain multiple filter conditions
#' rather than using compound expressions.
#'
#' @seealso
#' \code{\link{mutate.tbl_gpu}} for creating new columns,
#' \code{\link{select.tbl_gpu}} for selecting columns,
#' \code{\link{collect.tbl_gpu}} for retrieving results
#'
#' @export
#' @importFrom dplyr filter
#'
#' @examples
#' if (has_gpu()) {
#'   gpu_mtcars <- tbl_gpu(mtcars)
#'
#'   # Filter with single condition
#'   efficient_cars <- gpu_mtcars |>
#'     filter(mpg > 25)
#'
#'   # Multiple conditions (combined with AND)
#'   result <- gpu_mtcars |>
#'     filter(mpg > 20) |>
#'     filter(cyl == 4) |>
#'     collect()
#'
#'   # Compare two columns
#'   gpu_cars <- tbl_gpu(cars)
#'   fast_stops <- gpu_cars |>
#'     filter(dist < speed) |>
#'     collect()
#' }
filter.tbl_gpu <- function(.data, ..., .preserve = FALSE) {
  dots <- rlang::enquos(...)

  if (length(dots) == 0) return(.data)

  # Lazy path: build AST instead of executing
 if (.data$exec_mode == "lazy") {
    return(filter_lazy(.data, dots))
  }

  # Eager path: execute immediately
  result <- .data
  for (expr in dots) {
    result <- filter_one(result, expr)
  }

  result
}

# Lazy filter: build AST node
filter_lazy <- function(.data, dots) {
  # Parse all filter expressions into predicates
  predicates <- list()

  for (expr in dots) {
    parsed <- parse_filter_expr(expr, .data)
    if (is.null(parsed)) {
      # Opaque expression - fall back to eager
      warning("Opaque filter expression, falling back to eager execution",
              call. = FALSE)
      .data <- as_eager(.data)
      for (e in dots) {
        .data <- filter_one(.data, e)
      }
      return(as_lazy(.data))
    }
    predicates <- c(predicates, parsed)
  }

  # Initialize AST if needed
  if (is.null(.data$lazy_ops)) {
    .data$lazy_ops <- ast_source(.data$schema)
  }

  # Add filter node
  .data$lazy_ops <- ast_filter(.data$lazy_ops, predicates)

  # Schema unchanged by filter
  .data
}

# Parse a filter expression into predicate structure(s)
parse_filter_expr <- function(expr, .data) {
  expr_chr <- rlang::quo_text(expr)
  expr_obj <- rlang::quo_get_expr(expr)

  # Handle boolean literals without evaluating in a data mask
  if (identical(expr_obj, TRUE)) {
    return(list())  # TRUE = no filter needed
  }
  if (identical(expr_obj, FALSE)) {
    # FALSE = filter everything - create impossible predicate
    if (length(.data$schema$names) > 0) {
      return(list(make_predicate(.data$schema$names[1], "!=", .data$schema$names[1],
                                 is_col_compare = TRUE)))
    }
    return(list())
  }

  # Parse comparison expression
  ops <- c("==", "!=", ">=", "<=", ">", "<")
  op_found <- NULL

  for (op in ops) {
    if (grepl(op, expr_chr, fixed = TRUE)) {
      op_found <- op
      break
    }
  }

  if (is.null(op_found)) {
    return(NULL)  # Opaque expression
  }

  parts <- strsplit(expr_chr, op_found, fixed = TRUE)[[1]]
  if (length(parts) != 2) {
    return(NULL)
  }

  lhs <- trimws(parts[1])
  rhs <- trimws(parts[2])

  # Validate LHS is a column
  if (!lhs %in% .data$schema$names) {
    return(NULL)
  }

  # Check if RHS is a column
  if (rhs %in% .data$schema$names) {
    return(list(make_predicate(lhs, op_found, rhs, is_col_compare = TRUE)))
  }

  # Try to parse RHS as value
  value <- tryCatch(eval(parse(text = rhs)), error = function(e) NULL)
  if (is.null(value) || !is.numeric(value) || length(value) != 1) {
    return(NULL)
  }

  list(make_predicate(lhs, op_found, value, is_col_compare = FALSE))
}

# Internal: Parse and execute a single filter expression
#
# Parses a quosure containing a comparison expression and calls the
# appropriate GPU filter function.
#
# @param .data A tbl_gpu object
# @param expr A quosure with a comparison expression
# @return A filtered tbl_gpu object
# @keywords internal
filter_one <- function(.data, expr) {
  expr_chr <- rlang::quo_text(expr)
  expr_obj <- rlang::quo_get_expr(expr)
  ops <- c("==", "!=", ">=", "<=", ">", "<")

  # Handle literal TRUE/FALSE without evaluation
  if (identical(expr_obj, TRUE) || identical(expr_obj, FALSE)) {
    return(filter_logical(.data, expr_obj))
  }

  # If expression is a symbol not matching a column, allow logical vectors
  if (rlang::is_symbol(expr_obj)) {
    sym <- as.character(expr_obj)
    if (!sym %in% .data$schema$names) {
      eval_result <- tryCatch(rlang::eval_tidy(expr), error = function(e) NULL)
      if (!is.null(eval_result) && is.logical(eval_result)) {
        return(filter_logical(.data, eval_result))
      }
    }
  }

  # Allow non-comparison calls to be evaluated as logical vectors
  if (rlang::is_call(expr_obj)) {
    call_name <- rlang::call_name(expr_obj)
    if (is.null(call_name) || !call_name %in% ops) {
      eval_result <- tryCatch(rlang::eval_tidy(expr), error = function(e) NULL)
      if (!is.null(eval_result) && is.logical(eval_result)) {
        return(filter_logical(.data, eval_result))
      }
    }
  }

  # Parse simple comparison: col op value or col op col
  # Order matters: check two-char operators before single-char
  op_found <- NULL
  for (op in ops) {
    if (grepl(op, expr_chr, fixed = TRUE)) {
      op_found <- op
      break
    }
  }

  if (is.null(op_found)) {
    stop("filter() only supports comparisons: ==, !=, >, >=, <, <=\n",
         "Or logical values: TRUE, FALSE, logical vectors\n",
         "Expression: ", expr_chr, call. = FALSE)
  }

  parts <- strsplit(expr_chr, op_found, fixed = TRUE)[[1]]
  if (length(parts) != 2) {
    stop("Invalid filter expression: ", expr_chr,
         "\nExpected format: column ", op_found, " value", call. = FALSE)
  }

  lhs <- trimws(parts[1])
  rhs <- trimws(parts[2])

  lhs_idx <- tryCatch(col_index(.data, lhs), error = function(e) NULL)
  rhs_idx <- tryCatch(col_index(.data, rhs), error = function(e) NULL)

  if (is.null(lhs_idx)) {
    stop("Column '", lhs, "' not found.\n",
         "Available columns: ", paste(.data$schema$names, collapse = ", "),
         call. = FALSE)
  }

  if (!is.null(rhs_idx)) {
    # Column to column comparison
    new_ptr <- gpu_filter_col(.data$ptr, lhs_idx, op_found, rhs_idx)
  } else {
    # Column to scalar comparison
    value <- tryCatch(eval(parse(text = rhs)), error = function(e) {
      stop("Cannot parse value: ", rhs, call. = FALSE)
    })
    if (!is.numeric(value) || length(value) != 1) {
      stop("filter() currently only supports numeric scalar comparisons.\n",
           "Got: ", class(value)[1], " of length ", length(value), call. = FALSE)
    }
    new_ptr <- gpu_filter_scalar(.data$ptr, lhs_idx, op_found, as.double(value))
  }

  new_tbl_gpu(
    ptr = new_ptr,
    schema = .data$schema,
    groups = .data$groups,
    exec_mode = .data$exec_mode
  )
}

# Internal: Filter by logical value or vector
#
# @param .data A tbl_gpu object
# @param logical_val A logical scalar or vector
# @return A filtered tbl_gpu object
# @keywords internal
filter_logical <- function(.data, logical_val) {
  n_rows <- dim(.data)[1]

  if (length(logical_val) == 1) {
    # Single boolean: TRUE keeps all rows, FALSE keeps none
    if (isTRUE(logical_val)) {
      new_ptr <- gpu_filter_bool(.data$ptr, TRUE)
    } else {
      new_ptr <- gpu_filter_bool(.data$ptr, FALSE)
    }
  } else {
    # Logical vector: use as mask
    if (length(logical_val) != n_rows) {
      stop("Logical vector length (", length(logical_val),
           ") must match number of rows (", n_rows, ")", call. = FALSE)
    }

    # Check for all TRUE or all FALSE (optimize common cases)
    if (all(logical_val, na.rm = TRUE) && !any(is.na(logical_val))) {
      new_ptr <- gpu_filter_bool(.data$ptr, TRUE)
    } else if (!any(logical_val, na.rm = TRUE)) {
      new_ptr <- gpu_filter_bool(.data$ptr, FALSE)
    } else {
      # Mixed: apply mask
      new_ptr <- gpu_filter_mask(.data$ptr, logical_val)
    }
  }

  new_tbl_gpu(
    ptr = new_ptr,
    schema = .data$schema,
    groups = .data$groups,
    exec_mode = .data$exec_mode
  )
}
