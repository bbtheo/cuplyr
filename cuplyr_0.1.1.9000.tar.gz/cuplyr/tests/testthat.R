# This file is part of the standard setup for testthat.
# It is read by testthat when running tests.

library(testthat)
library(cuplyr)

test_check("cuplyr")
